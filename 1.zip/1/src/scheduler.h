#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <stdlib.h>

#define MAX_TASKS 100
#define NUM_QUEUES 4

// Görev durumları
typedef enum {
    TASK_READY,
    TASK_RUNNING,
    TASK_WAITING,
    TASK_TERMINATED
} TaskState;

// Görev yapısı
typedef struct {
    int id;
    int arrival_time;
    int priority;
    int burst_time;
    int remaining_time;
    TaskState state;
} Task;

// Kuyruk yapısı
typedef struct {
    Task* items[MAX_TASKS];
    int front;
    int rear;
    int count;
} TaskQueue;

// Global kuyruklar
extern TaskQueue queues[NUM_QUEUES];

// Fonksiyonlar
void run_scheduler();

void init_queue(TaskQueue* q);
void enqueue(TaskQueue* q, Task* t);
Task* dequeue(TaskQueue* q);

Task* create_task(int arrival, int priority, int burst);

#endif
