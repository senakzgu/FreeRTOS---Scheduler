#include "scheduler.h"

int main() {
    run_scheduler();
    return 0;
}
